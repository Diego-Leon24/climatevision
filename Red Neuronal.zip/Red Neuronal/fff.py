import requests

# URL de la API de OpenWeatherMap
url = "https://api.openweathermap.org/data/2.5/weather?q=Tingo%20Maria&appid=083a9058653cf5ba121f7cba5d9a1526"

# Realiza una solicitud GET a la API
response = requests.get(url)

# Comprueba si la solicitud fue exitosa (código de estado 200)
if response.status_code == 200:
    # Convierte la respuesta JSON en un diccionario de Python
    data = response.json()
    
    # Extrae la temperatura mínima y máxima del diccionario en Kelvin
    temp_min_kelvin = data["main"]["temp_min"]
    temp_max_kelvin = data["main"]["temp_max"]
    
    # Convierte las temperaturas a grados Celsius
    temp_min_celsius = temp_min_kelvin - 273.15
    temp_max_celsius = temp_max_kelvin - 273.15
    
    # Imprime los valores en grados Celsius
    print("Temperatura Mínima:", temp_min_celsius, "°C")
    print("Temperatura Máxima:", temp_max_celsius, "°C")
else:
    print("Error al obtener datos del clima")
