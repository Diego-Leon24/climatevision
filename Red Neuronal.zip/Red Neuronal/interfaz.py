import tkinter as tk

def activar_cerebro():
    lienzo.itemconfig(cerebro_ovalo, fill="green", outline="black")

def cerrar_ventana():
    ventana.destroy()

ventana = tk.Tk()
ventana.title("Interfaz de Red Neuronal")

# Creamos el lienzo principal para la interfaz gráfica
lienzo = tk.Canvas(ventana, width=400, height=200, bg="lightgray")
lienzo.pack()

# Creamos el óvalo que representa el cerebro
cerebro_ovalo = lienzo.create_oval(150, 50, 250, 150, outline="black", fill="white", width=2)

# Botón para activar el cerebro
boton_activar = tk.Button(ventana, text="Activar Cerebro", command=activar_cerebro, bg="lightblue", fg="black", font=("Arial", 12))
boton_activar.place(x=150, y=170)

# Botón para cerrar la ventana
boton_cerrar = tk.Button(ventana, text="Cerrar", command=cerrar_ventana, bg="red", fg="white", font=("Arial", 12))
boton_cerrar.place(x=300, y=170)

ventana.mainloop()
