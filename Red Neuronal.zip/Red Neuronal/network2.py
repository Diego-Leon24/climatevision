import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error, r2_score

# Cargar tus datos en el DataFrame 'df'
ruta = "C:\\Users\\fairy\\Downloads\\proyecto -75\\Red Neuronal\\datos_entrenamiento.csv"
df = pd.read_csv(ruta, sep=';')

# Eliminar columnas no relevantes para el modelo (si es necesario)
columnas_no_relevantes = ['Año', 'Mes', 'Dia', 'Precipitacion']
df = df.drop(columns=columnas_no_relevantes)

# Asegurarse de mantener al menos una columna relevante en X_train
columnas_relevantes = ['Tmaxima', 'Tminima', 'O3']  # Ejemplo: conserva estas columnas

# Escalar las características para normalizarlas
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df[columnas_relevantes].values)
y = df[columnas_relevantes].values

# Dividir los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Define modelos separados para cada variable
model_Tmaxima = tf.keras.Sequential([
    tf.keras.layers.Conv1D(64, 3, activation='relu', input_shape=(X_train.shape[1], 1)),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(units=64, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(units=32, activation='relu'),
    tf.keras.layers.Dense(units=1)
])

model_Tminima = tf.keras.Sequential([
    tf.keras.layers.Conv1D(64, 3, activation='relu', input_shape=(X_train.shape[1], 1)),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(units=64, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(units=32, activation='relu'),
    tf.keras.layers.Dense(units=1)
])

model_O3 = tf.keras.Sequential([
    tf.keras.layers.Conv1D(64, 3, activation='relu', input_shape=(X_train.shape[1], 1)),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(units=64, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(units=32, activation='relu'),
    tf.keras.layers.Dense(units=1)
])

# Compilar los modelos
model_Tmaxima.compile(optimizer='adam', loss='mean_squared_error')
model_Tminima.compile(optimizer='adam', loss='mean_squared_error')
model_O3.compile(optimizer='adam', loss='mean_squared_error')

# Entrenar los modelos
history_Tmaxima = model_Tmaxima.fit(X_train, y_train[:, 0], epochs=100, batch_size=64, validation_split=0.2, verbose=1)
history_Tminima = model_Tminima.fit(X_train, y_train[:, 1], epochs=100, batch_size=64, validation_split=0.2, verbose=1)
history_O3 = model_O3.fit(X_train, y_train[:, 2], epochs=100, batch_size=64, validation_split=0.2, verbose=1)

# Evaluar los modelos en los datos de prueba
y_pred_Tmaxima = model_Tmaxima.predict(X_test)
y_pred_Tminima = model_Tminima.predict(X_test)
y_pred_O3 = model_O3.predict(X_test)


mae_Tmaxima = mean_absolute_error(y_test[:, 0], y_pred_Tmaxima)
mse_Tmaxima = mean_squared_error(y_test[:, 0], y_pred_Tmaxima)
mape_Tmaxima = mean_absolute_percentage_error(y_test[:, 0], y_pred_Tmaxima)
r2_Tmaxima = r2_score(y_test[:, 0], y_pred_Tmaxima)

mae_Tminima = mean_absolute_error(y_test[:, 1], y_pred_Tminima)
mse_Tminima = mean_squared_error(y_test[:, 1], y_pred_Tminima)
mape_Tminima = mean_absolute_percentage_error(y_test[:, 1], y_pred_Tminima)
r2_Tminima = r2_score(y_test[:, 1], y_pred_Tminima)

mae_O3 = mean_absolute_error(y_test[:, 2], y_pred_O3)
mse_O3 = mean_squared_error(y_test[:, 2], y_pred_O3)
mape_O3 = mean_absolute_percentage_error(y_test[:, 2], y_pred_O3)
r2_O3 = r2_score(y_test[:, 2], y_pred_O3)

print('Tmaxima:')
print('Error absoluto medio (MAE):', mae_Tmaxima)
print('Error cuadrado medio (MSE):', mse_Tmaxima)
print('Error porcentual absoluto medio (MAPE):', mape_Tmaxima)
print('Coeficiente de determinación (R-squared):', r2_Tmaxima)

print('Tminima:')
print('Error absoluto medio (MAE):', mae_Tminima)
print('Error cuadrado medio (MSE):', mse_Tminima)
print('Error porcentual absoluto medio (MAPE):', mape_Tminima)
print('Coeficiente de determinación (R-squared):', r2_Tminima)

print('O3:')
print('Error absoluto medio (MAE):', mae_O3)
print('Error cuadrado medio (MSE):', mse_O3)
print('Error porcentual absoluto medio (MAPE):', mape_O3)
print('Coeficiente de determinación (R-squared):', r2_O3)

# Visualización de Resultados para Tmaxima
plt.figure(figsize=(12, 6))
plt.plot(y_test[:, 0], label='Tmaxima Real', marker='o')
plt.plot(y_pred_Tmaxima, label='Tmaxima Predicha', marker='x')
plt.xlabel('Índice de Tiempo')
plt.ylabel('Tmaxima')
plt.title('Predicción de Tmaxima vs. Real')
plt.legend()
plt.show()

# Visualización de Resultados para Tminima
plt.figure(figsize=(12, 6))
plt.plot(y_test[:, 1], label='Tminima Real', marker='o')
plt.plot(y_pred_Tminima, label='Tminima Predicha', marker='x')
plt.xlabel('Índice de Tiempo')
plt.ylabel('Tminima')
plt.title('Predicción de Tminima vs. Real')
plt.legend()
plt.show()

# Visualización de Resultados para O3
plt.figure(figsize=(12, 6))
plt.plot(y_test[:, 2], label='O3 Real', marker='o')
plt.plot(y_pred_O3, label='O3 Predicho', marker='x')
plt.xlabel('Índice de Tiempo')
plt.ylabel('O3')
plt.title('Predicción de O3 vs. Real')
plt.legend()
plt.show()


#----------------------------------------------------------------
# Supongamos que tienes modelos previamente entrenados llamados model_Tmaxima, model_Tminima y model_O3

# Ruta donde guardarás los modelos
ruta_guardado = 'modelos_entrenados_100/'

# Guarda el modelo de Tmaxima en un archivo llamado 'modelo_Tmaxima.h5'
model_Tmaxima.save(ruta_guardado + 'modelo_Tmaxima.h5')

# Guarda el modelo de Tminima en un archivo llamado 'modelo_Tminima.h5'
model_Tminima.save(ruta_guardado + 'modelo_Tminima.h5')

# Guarda el modelo de O3 en un archivo llamado 'modelo_O3.h5'
model_O3.save(ruta_guardado + 'modelo_O3.h5')
#----------------------------------------------------------------
