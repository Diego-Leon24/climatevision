import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

# Cargar tus datos en el DataFrame 'df'
ruta = "C:\\Users\\fairy\\Downloads\\Nueva carpeta (5)\\Red Neuronal\\datos_entrenamiento.csv"
df = pd.read_csv(ruta, sep=';')

# Eliminar columnas no relevantes para el modelo (si es necesario)
columnas_no_relevantes = ['Año', 'Mes', 'Dia', 'Precipitacion']
df = df.drop(columns=columnas_no_relevantes)

# Asegurarse de mantener al menos una columna relevante en X_train
columnas_relevantes = ['Tmaxima', 'Tminima', 'O3']  # Ejemplo: conserva estas columnas

# Escalar las características para normalizarlas
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df[columnas_relevantes].values)
y = df[columnas_relevantes].values

# se carga los valores ya guardados 
ruta_guardado = 'C:\\Users\\fairy\\Downloads\\Nueva carpeta (5)\\modelos_entrenados_200\\'

# Cargar el modelo de Tmaxima
model_Tmaxima = tf.keras.models.load_model(ruta_guardado + 'modelo_Tmaxima.h5')

# Cargar el modelo de Tminima
model_Tminima = tf.keras.models.load_model(ruta_guardado + 'modelo_Tminima.h5')

# Cargar el modelo de O3
model_O3 = tf.keras.models.load_model(ruta_guardado + 'modelo_O3.h5')


# Solicitar al usuario que ingrese una fecha en el formato "YYYY-MM-DD"
fecha_str = input("Por favor, ingresa una fecha en el formato YYYY-MM-DD: ")

try:
    # Intentar convertir la cadena ingresada en un objeto de fecha
    fecha_futura = pd.to_datetime(fecha_str)

    # Imprimir la fecha convertida
    print("Fecha ingresada:", fecha_futura)
except ValueError:
    print("La fecha ingresada no tiene el formato correcto. Asegúrate de usar el formato YYYY-MM-DD.")




# Preparar los datos futuros (reemplaza estos valores con tus datos reales)
datos_futuros = np.array([[model_Tmaxima, model_Tminima, model_O3]])  # Ejemplo de valores de entrada para Tmaxima, Tminima y O3

# Escalar los datos futuros
datos_futuros_scaled = scaler.transform(datos_futuros)

# Realizar la predicción para Tmaxima
prediccion_Tmaxima = model_Tmaxima.predict(datos_futuros_scaled)

# Realizar la predicción para Tminima
prediccion_Tminima = model_Tminima.predict(datos_futuros_scaled)

# Realizar la predicción para O3
prediccion_O3 = model_O3.predict(datos_futuros_scaled)

# Imprimir las predicciones
print("Fecha Futura:", fecha_futura)
print("Predicción Tmaxima:", prediccion_Tmaxima[0][0])
print("Predicción Tminima:", prediccion_Tminima[0][0])
print("Predicción O3:", prediccion_O3[0][0])
