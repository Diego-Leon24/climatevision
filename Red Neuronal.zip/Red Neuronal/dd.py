# Supongamos que tienes datos de entrada en un arreglo 'datos_futuros', donde cada fila corresponde a una observación.
# Asegúrate de que 'datos_futuros' tenga las mismas columnas y escalas que los datos de entrenamiento.
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

ruta_guardado = 'C:\\Users\\fairy\\Downloads\\Nueva carpeta (5)\\modelos_entrenados_200\\'

# Cargar el modelo de Tmaxima
model_Tmaxima = tf.keras.models.load_model(ruta_guardado + 'modelo_Tmaxima.h5')

# Cargar el modelo de Tminima
model_Tminima = tf.keras.models.load_model(ruta_guardado + 'modelo_Tminima.h5')

# Cargar el modelo de O3
model_O3 = tf.keras.models.load_model(ruta_guardado + 'modelo_O3.h5')



import requests

# URL de la API de OpenWeatherMap
url = "https://api.openweathermap.org/data/2.5/weather?q=Tingo%20Maria&appid=083a9058653cf5ba121f7cba5d9a1526"

# Realiza una solicitud GET a la API
response = requests.get(url)

# Comprueba si la solicitud fue exitosa (código de estado 200)
if response.status_code == 200:
    # Convierte la respuesta JSON en un diccionario de Python
    data = response.json()
    
    # Extrae la temperatura mínima y máxima del diccionario en Kelvin
    temp_min_kelvin = data["main"]["temp_min"]
    temp_max_kelvin = data["main"]["temp_max"]
    
    # Convierte las temperaturas a grados Celsius
    temp_min_celsius = temp_min_kelvin - 273.15
    temp_max_celsius = temp_max_kelvin - 273.15
else:
    print("Error al obtener datos del clima")


# Supongamos que tienes datos de entrada en un arreglo 'datos_futuros', donde cada fila corresponde a una observación.
# Asegúrate de que 'datos_futuros' tenga las mismas columnas y escalas que los datos de entrenamiento.

# Realizar la predicción para Tmaxima
prediccion_Tmaxima = model_Tmaxima.predict(temp_max_celsius)

# Realizar la predicción para Tminima
prediccion_Tminima = model_Tminima.predict(temp_min_celsius)

# Realizar la predicción para O3
#prediccion_O3 = model_O3.predict(datos_futuros)

# Imprimir las predicciones
print("Predicción Tmaxima:", prediccion_Tmaxima)
print("Predicción Tminima:", prediccion_Tminima)
#print("Predicción O3:", prediccion_O3)
