import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error, r2_score

# Cargar tus datos en el DataFrame 'df'
ruta = "C:\\Users\\fairy\\Downloads\\proyecto -75\\Red Neuronal\\datos_entrenamiento.csv"
df = pd.read_csv(ruta, sep=';')

# Eliminar columnas no relevantes para el modelo (si es necesario)
columnas_no_relevantes = ['Año', 'Mes', 'Dia', 'Precipitacion']
df = df.drop(columns=columnas_no_relevantes)

# Aplicar logaritmo más uno a los valores de O3
df['O3'] = np.log1p(df['O3'])

# Asegurarse de mantener al menos una columna relevante en X_train
columnas_relevantes = ['Tmaxima', 'Tminima', 'O3']  # Ejemplo: conserva estas columnas

# Escalar las características para normalizarlas
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df[columnas_relevantes].values)
y = df[columnas_relevantes].values

# Dividir los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Define un modelo CNN para Tmaxima
model_Tmaxima = tf.keras.Sequential([
    tf.keras.layers.Reshape((X_train.shape[1], 1), input_shape=(X_train.shape[1],)),
    tf.keras.layers.Conv1D(64, 3, activation='relu'),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(units=64, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(units=32, activation='relu'),
    tf.keras.layers.Dense(units=1)
])

# Define un modelo CNN para Tminima
model_Tminima = tf.keras.Sequential([
    tf.keras.layers.Reshape((X_train.shape[1], 1), input_shape=(X_train.shape[1],)),
    tf.keras.layers.Conv1D(64, 3, activation='relu'),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(units=64, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(units=32, activation='relu'),
    tf.keras.layers.Dense(units=1)
])

# Define un modelo CNN para O3
model_O3_cnn = tf.keras.Sequential([
    tf.keras.layers.Reshape((X_train.shape[1], 1), input_shape=(X_train.shape[1],)),
    tf.keras.layers.Conv1D(64, 3, activation='relu'),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(units=64, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(units=32, activation='relu'),
    tf.keras.layers.Dense(units=1)
])

# Compilar los modelos
model_Tmaxima.compile(optimizer='adam', loss='mean_squared_error')
model_Tminima.compile(optimizer='adam', loss='mean_squared_error')
model_O3_cnn.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), loss='mean_squared_error')

# Entrenar los modelos
history_Tmaxima = model_Tmaxima.fit(X_train, y_train[:, 0], epochs=100, batch_size=64, validation_split=0.2, verbose=1)
history_Tminima = model_Tminima.fit(X_train, y_train[:, 1], epochs=100, batch_size=64, validation_split=0.2, verbose=1)
history_O3_cnn = model_O3_cnn.fit(X_train, y_train[:, 2], epochs=200, batch_size=64, validation_split=0.2, verbose=1)

# Evaluar los modelos en los datos de prueba
y_pred_Tmaxima = model_Tmaxima.predict(X_test)
y_pred_Tminima = model_Tminima.predict(X_test)
y_pred_O3_cnn = model_O3_cnn.predict(X_test)

# Transformar las predicciones de O3 al espacio original
y_pred_O3_cnn_original = np.expm1(y_pred_O3_cnn)
y_test_O3_original = np.expm1(y_test[:, 2])

mae_Tmaxima = mean_absolute_error(y_test[:, 0], y_pred_Tmaxima)
mse_Tmaxima = mean_squared_error(y_test[:, 0], y_pred_Tmaxima)
mape_Tmaxima = mean_absolute_percentage_error(y_test[:, 0], y_pred_Tmaxima)
r2_Tmaxima = r2_score(y_test[:, 0], y_pred_Tmaxima)

mae_Tminima = mean_absolute_error(y_test[:, 1], y_pred_Tminima)
mse_Tminima = mean_squared_error(y_test[:, 1], y_pred_Tminima)
mape_Tminima = mean_absolute_percentage_error(y_test[:, 1], y_pred_Tminima)
r2_Tminima = r2_score(y_test[:, 1], y_pred_Tminima)

mae_O3_cnn = mean_absolute_error(y_test_O3_original, y_pred_O3_cnn_original)
mse_O3_cnn = mean_squared_error(y_test_O3_original, y_pred_O3_cnn_original)
mape_O3_cnn = mean_absolute_percentage_error(y_test_O3_original, y_pred_O3_cnn_original)
r2_O3_cnn = r2_score(y_test_O3_original, y_pred_O3_cnn_original)

# Visualización de Resultados para Tmaxima
plt.figure(figsize=(12, 6))
plt.subplot(3, 1, 1)
plt.plot(y_test[:, 0], label='Tmaxima Real', marker='o')
plt.plot(y_pred_Tmaxima, label='Tmaxima Predicha', marker='x')
plt.xlabel('Índice de Tiempo')
plt.ylabel('Tmaxima')
plt.title('Predicción de Tmaxima vs. Real')
plt.legend()

# Visualización de Resultados para Tminima
plt.subplot(3, 1, 2)
plt.plot(y_test[:, 1], label='Tminima Real', marker='o')
plt.plot(y_pred_Tminima, label='Tminima Predicha', marker='x')
plt.xlabel('Índice de Tiempo')
plt.ylabel('Tminima')
plt.title('Predicción de Tminima vs. Real')
plt.legend()

# Visualización de Resultados para O3
plt.subplot(3, 1, 3)
plt.plot(y_test_O3_original, label='O3 Real', marker='o')
plt.plot(y_pred_O3_cnn_original, label='O3 Predicho', marker='x')
plt.xlabel('Índice de Tiempo')
plt.ylabel('O3 (original)')
plt.title('Predicción de O3 vs. Real')
plt.legend()

print('Tmaxima:')
print('Error absoluto medio (MAE):', mae_Tmaxima)
print('Error cuadrado medio (MSE):', mse_Tmaxima)
print('Error porcentual absoluto medio (MAPE):', mape_Tmaxima)
print('Coeficiente de determinación (R-squared):', r2_Tmaxima)

print('Tminima:')
print('Error absoluto medio (MAE):', mae_Tminima)
print('Error cuadrado medio (MSE):', mse_Tminima)
print('Error porcentual absoluto medio (MAPE):', mape_Tminima)
print('Coeficiente de determinación (R-squared):', r2_Tminima)

print('Modelo O3 (CNN):')
print('Error absoluto medio (MAE):', mae_O3_cnn)
print('Error cuadrado medio (MSE):', mse_O3_cnn)
print('Error porcentual absoluto medio (MAPE):', mape_O3_cnn)
print('Coeficiente de determinación (R-squared):', r2_O3_cnn)
