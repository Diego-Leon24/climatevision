import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error, r2_score

# Cargar tus datos en el DataFrame 'df'
ruta = "C:\\Users\\fairy\\Downloads\\Nueva carpeta (5)\\Red Neuronal\\datos_entrenamiento.csv"
#df = pd.read_csv(ruta, sep=';')

# Eliminar columnas no relevantes para el modelo (si es necesario)
columnas_no_relevantes = ['Año', 'Mes', 'Dia', 'Precipitacion']
#df = df.drop(columns=columnas_no_relevantes)

# Asegurarse de mantener al menos una columna relevante en X_train
#columnas_relevantes = ['Tmaxima', 'Tminima', 'O3']  # Ejemplo: conserva estas columnas

